<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/**
 * route backend
 */

 /**
 * GET => category.index  danh sach du lieu
 * GET => category.create hien thi form tao moi
 * POST => category.store submit form them moi
 * GET => category.show xem chi tiet
 * GET => category.edit hien thi form sua
 * PUT => category.update cap nhat thong tin
 * DELETE => category.destroy xoa thong tin
 */
Route::group(['middleware'=>['authcheck'], 'prefix'=>'admin'], function(){
    Route::get('/', 'AdminController@dashboard')->name('admin.dashboard'); 
    Route::get('/file', 'AdminController@file')->name('admin.file'); 
    Route::get('/logout','AuthController@logout')->name('admin.logout');
    Route::resources([
        'category' => 'CategoryController',
        'product' => 'ProductController',
        'banner' => 'BannerController',
        'blog'=>'BlogController',
        'account' => 'AccountController',
        'order' => 'OrderController'
    ]);

});
#user
Route::group(['prefix'=>'auth'], function(){
Route::get('/login','AuthController@login')->name('auth.login');
Route::post('/check','AuthController@check')->name('auth.check');
Route::get('/register','AuthController@register')->name('auth.register');
Route::post('/save','AuthController@save')->name('auth.save');
});


Route::get('/', 'HomeController@index')->name('home.index');
Route::get('/shop.html', 'HomeController@shop')->name('home.shop');


Route::get('/gioi-thieu', function () {
    $name = "Day la trang gioi thieu";
    return view('abount', compact('name'));
});
//Category
Route::get('category1', 'Category1Controller@index');
Route::get('category1/{id}', 'Category1Controller@view');