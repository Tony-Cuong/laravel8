@extends('layouts.admin')
@section('title','Files managers')
@section('main')
    <iframe src="{{url('public/file/dialog.php')}}" frameborder="0" style="width:100%; "></iframe>
@stop()