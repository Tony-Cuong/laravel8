@extends('layouts.admin')
@section('title','Edit Category')
@section('main')
<div class="container">
    <form action="{{route('category.update', $category->id)}}" method="POST" role="from">
        @csrf @method('PUT')
        <input type="hidden" name="id" value="{{$category->id}}">
    <div class="form-group">
      <label for="">Name</label>
      <input type="text" name="name" value="{{$category->name}}" class="form-control" placeholder="Input Name">
      @error('name')
      <small class="help-block">{{$message}}</small>
      @enderror
    </div>
      <label for="">Status</label>
      <div class="form-group">
          <label class="">
          <input type="radio" class="" name="status" id="status" value="1" checked>
          Public
        </label>
        <label class="">
        <input type="radio" class="" name="status" value="0">
        Private
        </label>
      </div>
      <div class="form-group">
        <label for="">Prioty</label>
        <input type="number" name="prioty" value="{{$category->prioty}}" class="form-control">
        @error('prioty')
        <small id="helpId" class="help-block">{{$message}}</small>
        @enderror
      </div>
      <a href="{{route('category.index')}}" class="btn btn-secondary" tabindex="5">Cancel</a>
      <button type="submit" class="btn btn-primary" tabindex="4">Save data</button>
    </form>
</div>

@stop()