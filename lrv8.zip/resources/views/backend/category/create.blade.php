@extends('layouts.admin')
@section('title','Create Category')
@section('main')
<div class="container">
    <form action="{{route('category.store')}}" method="POST" role="from">
        @csrf
    <div class="form-group">
      <label for="">Name</label>
      <input type="text" name="name" id="" class="form-control" placeholder="Input Name">
      @error('name')
      <small class="help-block">{{$message}}</small>
      @enderror
    </div>
      <label for="">Status</label>
      <div class="form-group">
          <label class="">
          <input type="radio" class="" name="status" id="status" value="1" checked>
          Public
        </label>
        <label class="">
        <input type="radio" class="" name="status" value="0">
        Private
        </label>
      </div>
      <div class="form-group">
        <label for="">Prioty</label>
        <input type="text" name="prioty" id="" class="form-control">
        @error('prioty')
        <small id="helpId" class="help-block">{{$message}}</small>
        @enderror
      </div>
      <a href="{{route('category.index')}}" class="btn btn-secondary" tabindex="5">Cancel</a>
      <button type="submit" class="btn btn-primary" tabindex="4">Save data</button>
    </form>
</div>

@stop()