@extends('layouts.admin')
@section('main')
    <ul class="list-group">
        <li class="list-group-item d-flex justify-content-between align-items-center active">
            Active list item
            <span class="badge badge-secondary badge-pill">pill1</span>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            List item
            <span class="badge badge-secondary badge-pill">pill2</span>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-center disabled">
            Disabled item
            <span class="badge badge-secondary badge-pill">pill3</span>
        </li>
    </ul>
@stop()