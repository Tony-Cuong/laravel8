@extends('layouts.admin')
@section('title', 'Create product')
@section('main')
    <div class="container">
        <form action="{{ route('product.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="col-md-9">
                    <div class="form-group">
                        <label for="">Name</label>
                        <input type="text" name="name" id="" class="form-control" placeholder="Input Name">
                        @error('name')
                            <small class="help-block">{{ $message }}</small>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="">Description</label>
                        <textarea name="description" id="description" cols="30" rows="10"></textarea>
                        @error('description')
                            <small class="help-block">{{ $message }}</small>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="">Image List</label>
                        <div class="input-group">
                            <input type="text" name="image_list" id="image_list" class="form-control">
                            <span class="input-group-btn">
                                <!-- Button trigger modal -->
                                <button class="btn btn-secondary" type="button" data-toggle="modal" data-target="#imgList">
                                    <i class="fa fa-image" aria-hidden="true"></i>
                                </button>
                            </span>
                        </div>
                    </div>
                    <div class="row" id="show_img_list">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="">Category</label>
                        <select name="category_id" id="" class="form-control">
                            <option value="-">Select one</option>
                            @foreach ($cats as $cat)
                                <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Price</label>
                        <input type="text" name="price" id="" class="form-control" placeholder="Input price">
                    </div>
                    <div class="form-group">
                        <label for="">Sale Price</label>
                        <input type="text" name="sale_price" id="" class="form-control" placeholder="Input sale price">
                    </div>
                    <label for="">Status</label>
                    <div class="form-group">
                        <label class="">
                            <input type="radio" class="" name="status" id="status" value="1" checked>
                            Public
                        </label>
                        <label class="">
                            <input type="radio" class="" name="status" value="0">
                            Private
                        </label>
                    </div>
                    <div class="form-group">
                        <label for="">Image</label>
                        <!--<input type="file" name="file_upload" id="" class="form-control">-->
                        <div class="input-group">
                            <input type="text" class="form-control" name="img" id="img" aria-label="">
                            <span class="input-group-btn">
                                <!-- Button trigger modal -->
                                <button class="btn btn-secondary" type="button" data-toggle="modal" data-target="#modelId">
                                    <i class="fa fa-image" aria-hidden="true"></i>
                                </button>
                            </span>
                        </div>
                        <img src="" id="img" style="">
                    </div>
                </div>
            </div>

            <a href="{{ route('product.index') }}" class="btn btn-secondary" tabindex="5">Cancel</a>
            <button type="submit" class="btn btn-primary" tabindex="4">Save data</button>
        </form>
    </div>
@stop()


<!-- Modal -->
<div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-custom" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Media</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <iframe src="{{ url('public/file/dialog.php?field_id=img') }}" frameborder="0"
                    style="width:100%; hieght:500px; "></iframe>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save</button>
            </div>
        </div>
    </div>
</div>
<!--model media list-->
<div class="modal fade" id="imgList" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-custom" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Media</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <iframe src="{{ url('public/file/dialog.php?field_id=image_list') }}" frameborder="0"
                    style="width:100%; hieght:500px; "></iframe>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save</button>
            </div>
        </div>
    </div>
</div>

@section('js')
    <script src="{{ url('public/backend') }}/plugins/summernote/summernote-bs4.min.js"></script>
    <script>
        $('#description').summernote({
            height: 210,
            placeholder: "Product description"
        })

        $('#modelId').on('hide.bs.modal', event => {
            var _name_img = $('input#img').val();
            var _link = "{{ url('public/upload') }}/" + _name_img;
            $('img#img').attr('src', _link);
            $('img#img').attr('style', 'width:60px;');
        });

        $('#imgList').on('hide.bs.modal', event => {
            var _name_img = $('input#image_list').val();
            var _html = '';
            if (/^[\],:{}\s]*$/.test(_name_img.replace(/\\["\\\/bfnrtu]/g, '@').replace(
                    /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').replace(
                    /(?:^|:|,)(?:\s*\[)+/g, ''))) {
                var _array_img = $.parseJSON(_name_img);
                for (let i = 0; i < _array_img.length; i++) {
                    let _link_img = "{{ url('public/upload') }}/" + _array_img[i];
                    _html += '<div class="col-md-4">';
                    _html += '<img src="' + _link_img + '" alt="" style="width: 100%;">';
                    _html += '</div>';
                }
            } else {
                let _link_img = "{{ url('public/upload') }}/" + _name_img;
                _html += '<div class="col-md-4">';
                _html += '<img src="' + _link_img + '" alt="" style="width: 100%;">';
                _html += '</div>';
            }

            $('#show_img_list').html(_html);
        });
    </script>
@stop()

@section('css')
    <link rel="stylesheet" href="{{ url('public/backend') }}/plugins/summernote/summernote-bs4.min.css">
@stop()
