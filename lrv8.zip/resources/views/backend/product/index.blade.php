@extends('layouts.admin')
@section('title', 'Product list')
@section('main')
    <form class="form-inline">
        <div class="form-group">
            <label for="">Search</label>
            <input type="text" name="key" id="" class="form-control" placeholder="search" aria-describedby="helpId">
            <button type="submit" class="btn btn-primary" data-toggle="button" aria-pressed="false" autocomplete="off">
                <i class="fa fa-search" aria-hidden="true"></i>
            </button>
        </div>
    </form>
    <div class="btn-group-sm text-right" role="group" aria-label="">
        <a href="{{ route('product.create') }}" class="">Tao moi</a>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Sale price</th>
                    <th>description</th>
                    <th>Status</th>
                    <th>Create date</th>
                    <th class="text-center" style="width: 150px">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($data as $key => $product)
                    <tr>
                        <td>{{$key+1}}</td>
                        <td>
                            <img src="{{url('public/thumbs')}}/{{ $product->img }}" alt="product img" width="60">
                            
                        </td>
                        <td>{{ $product->name }}</td>
                        <td>{{$product->cat->name}}</td>
                        <td>{{ $product->price }}</td>
                        <td>{{ $product->sale_price }}</td>
                        <td>{!! $product->description !!}</td>
                        <td>
                            @if ($product->status == 0)
                                <span class="badge badge-danger">Private</span>
                            @else
                                <span class="badge badge-success">Public</span>
                            @endif

                        </td>
                        <td>{{ $product->created_at->format('d/m/Y') }}</td>
                        <td class="text-center">
                            <a name="" id="" class="" href="{{ route('product.edit', $product->id) }}"
                                role="button">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a name="" id="" href="{{ route('product.destroy', $product->id) }}" role="button"
                                class="btndelete">
                                <i class="fas fa-trash"></i>
                            </a>

                            <a name="" id="" class="" href="#" role="button">
                                <i class="fas fa-file"></i>
                            </a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <div class="card-footer clearfix">
            {{ $data->appends(request()->all())->links() }}
        </div>

    </div>
    </div>
    <form action="" method="post" id="form-delete">
        @csrf @method('DELETE')
    </form>
@stop()

@section('js')
    <script>
        $('.btndelete').click(function(event) {
            event.preventDefault();
            var _href = $(this).attr('href')
            $('form#form-delete').attr('action', _href)
            if (confirm('Ban co muon xoa khong?')) {
                $("form#form-delete").submit();
            }
        })
    </script>
@stop()
