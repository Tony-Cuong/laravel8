<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >
</head>
<body>
    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($data as $cat)
                <tr>
                    <td scope="row">{{$cat->id}}</td>
                    <td>{{$cat->name}}</td>
                    <td><a href="" class="btn btn-primary">View</a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
        <hr>
    <div class="">
        {{$data->links()}}
    </div>
    </div>
    
    
</body>
</html>