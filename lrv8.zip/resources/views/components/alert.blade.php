<div class="alert alert-success" role="alert">
  <h4 class="alert-heading"></h4>
  <p>{{$title}}</p>
  <hr>
  <p class="mb-0">{{$message}}</p>
  <p class="container">
    Name {{$getOwner('Cuong')}}
  </p>
  <p class="card-text">Weight: {{ $getWeight }}</p>
</div>