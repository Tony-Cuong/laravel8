<?php
return[
    [
        'label'=>'Dashboard',
        'route'=>'admin.dashboard',
        'icon'=>'fa-home'
    ],
    [
        'label'=>'Product Manager',
        'route'=>'product.index',
        'icon'=>'fa-th',
        'items'=> [
            [
            'label'=>'All product',
            'route'=>'product.index',
            'icon'=>'fa-list',
            ],
            [
            'label'=>'Add product',
            'route'=>'product.create',
            'icon'=>'fa-new',
            ]
        ]
    ],
    [
        'label'=>'Category Manager',
        'route'=>'category.index',
        'icon'=>'fa-th',
        'items'=> [
            [
            'label'=>'All category',
            'route'=>'category.index',
            'icon'=>'fa-list',
            ],
            [
            'label'=>'Add category',
            'route'=>'category.create',
            'icon'=>'fa-new',
            ]
        ]
    ],
    [
        'label'=>'Banner Manager',
        'route'=>'banner.index',
        'icon'=>'fa-th',
        'items'=> [
            [
            'label'=>'All banner',
            'route'=>'banner.index',
            'icon'=>'fa-list',
            ],
            [
            'label'=>'Add banner',
            'route'=>'banner.create',
            'icon'=>'fa-new',
            ]
        ]
    ],
    [
        'label'=>'Files Manager',
        'route'=>'admin.file',
        'icon'=>'fa-image',
    ]
]

?>