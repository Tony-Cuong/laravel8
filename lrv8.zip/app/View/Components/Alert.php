<?php

namespace App\View\Components;

use Illuminate\View\Component;

class Alert extends Component
{
    public $title = 'success';
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($title)
    {
        $this->title = $title;
    }
     /**
    * Get owner.
    *
    * @param  string  $name
    *
    * @return string
    */
    public function getOwner(string $name)
    {
        return 'This is ' . $name . "'s " . $this->title;
    }
     /**
    * Get weight.
    *
    * @return float
    */
    public function getWeight()
    {
        switch ($this->title) {
            case 'success':
                return 3.6;
            case 'danger':
                return 12;
            default:
                return 65;
        }
    }
    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        $message = 'Day la thong bao khi goi component';
        return view('components.alert', compact('message'));
    }
}
