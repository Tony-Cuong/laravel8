<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Blog;
class HomeController extends Controller
{
    //
    public function index()
    {
        # code...
        return view('fontend.site');
    }
    
    public function shop(){
        return view('fontend.shop');
    }


}
