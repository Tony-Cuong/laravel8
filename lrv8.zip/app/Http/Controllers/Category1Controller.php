<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
class Category1Controller extends Controller
{
    public function index()
    {
        # code...
        $data = Category::paginate(1);
        return view('category.index', compact('data'));
    }
    # get caegory by $id
    public function view($id)
    {
        # code...
        return view('category.view');
    }
}
