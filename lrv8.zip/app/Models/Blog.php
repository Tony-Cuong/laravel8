<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    use HasFactory;

    protected $table = "blog";

public static function getData()
{
    # code...
    return [ 
        'Bog 1',
        'Blog 2',
        'Blog 3',
        'Blog 4',
        'Blog 5',
    ];
}

}

?>
