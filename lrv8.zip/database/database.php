<?php

CREATE TABLE `category` (
  `id` int(10) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO `category` (`id`, `name`, `status`, `create_at`) VALUES (NULL, 'Áo', '1', '2022-02-12 16:54:48'), (NULL, 'Quần', '1', '2022-02-12 16:54:48');

CREATE TABLE `account` (
  `id` int(10) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `name` varchar(250) ,
  `email` varchar(250) ,
  `phone` varchar(250) ,
  `password` varchar(250) ,
  `address` varchar(250) ,
  `rule` varchar(250) DEFAULT 'customer',
  `status` int(11) DEFAULT NULL,
  `create_at` DATE NULL DEFAULT current_timestamp(),
  `updated_at` DATE NULL DEFAULT current_timestamp(),
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `banner` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(250) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
  `img` VARCHAR(250) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
  `link` VARCHAR(250) NULL DEFAULT '#' COLLATE 'utf8mb4_general_ci',
  `description` VARCHAR(250) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`status` INT(11) NULL DEFAULT NULL,
	`priory` INT(11) NULL DEFAULT NULL,
	`created_at` DATE NULL DEFAULT CURRENT_TIMESTAMP(),
	`updated_at` DATE NULL DEFAULT current_timestamp(),
	PRIMARY KEY (`id`) USING BTREE
)

CREATE TABLE `product` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(250) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`img` VARCHAR(250) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`price` FLOAT(9,3) NULL DEFAULT NULL,
	`sele_price` FLOAT(9,3) NULL DEFAULT '0.000',
	`description` TEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`image_list` TEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`status` INT(11) NULL DEFAULT NULL,
	`category_id` INT(11) NULL DEFAULT NULL,
	`created_at` DATE NULL DEFAULT current_timestamp(),
	`updated_at` DATE NULL DEFAULT current_timestamp(),
	PRIMARY KEY (`id`) USING BTREE,
	FOREIGN KEY (category_id) REFERENCES category(id)
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
;

CREATE TABLE `blog` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(250) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
  `img` VARCHAR(250) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
  `sumary` VARCHAR(250) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
  `description` text NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`status` INT(11) NULL DEFAULT NULL,
  `account_id` INT(11),
	`created_at` DATE NULL DEFAULT CURRENT_TIMESTAMP(),
	`updated_at` DATE NULL DEFAULT current_timestamp(),
	PRIMARY KEY (`id`) USING BTREE,
  FOREIGN KEY (account_id) REFERENCES account(id)
)


CREATE TABLE `order` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(250) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
  `email` varchar(250) ,
  `phone` varchar(250) ,
  `address` varchar(250) ,
  `note` text NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`status` INT(11) NULL DEFAULT NULL,
  `account_id` INT(11) ,
	`created_at` DATE NULL DEFAULT CURRENT_TIMESTAMP(),
	`updated_at` DATE NULL DEFAULT current_timestamp(),
	PRIMARY KEY (`id`) USING BTREE
)

CREATE TABLE `order_detail` (
	`product_id` INT(10) ,
  `order_id` INT(10) ,
	`quantity` INT(10) ,
	`price` float(9,3),
	`created_at` DATE NULL DEFAULT CURRENT_TIMESTAMP(),
	`updated_at` DATE NULL DEFAULT current_timestamp(),
	PRIMARY KEY (`id`) USING BTREE
)

?>