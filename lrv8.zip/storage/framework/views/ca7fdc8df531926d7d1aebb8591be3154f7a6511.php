
<?php $__env->startSection('title','Files managers'); ?>
<?php $__env->startSection('main'); ?>
    <iframe src="<?php echo e(url('public/file/dialog.php'), false); ?>" frameborder="0" style="width:100%; "></iframe>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\lrv8\resources\views/backend/file.blade.php ENDPATH**/ ?>