
<?php $__env->startSection('title', 'Category list'); ?>
<?php $__env->startSection('main'); ?>
<form class="form-inline">
    <div class="form-group">
        <label for="">Search</label>
        <input type="text" name="key" id="" class="form-control" placeholder="search" aria-describedby="helpId">
        <button type="submit" class="btn btn-primary" data-toggle="button" aria-pressed="false" autocomplete="off">
            <i class="fa fa-search" aria-hidden="true"></i>
        </button>
    </div>
</form>
<div class="btn-group-sm text-right" role="group" aria-label="">
    <a href="<?php echo e(route('category.create')); ?>" class="">Tao moi</a>
</div>
<div class="card-body">
    <table class="table table-bordered">
        <thead>
        <tr>
            <th style="width: 10px">#</th>
            <th>Name</th>
            <th>Total product</th>
            <th>Status</th>
            <th>Create date</th>
            <th class="text-center" style="width: 150px">Action</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cat->id); ?></td>
            <td><?php echo e($cat->name); ?></td>
            <td><?php echo e($cat->products()->count()); ?></td>
            <td>
            <?php if($cat->status == 0): ?>
                <span class="badge badge-danger">Private</span>
            <?php else: ?>
                <span class="badge badge-success">Public</span>
            <?php endif; ?>
            
            </td>
            <td><?php echo e($cat->created_at->format('d/m/Y')); ?></td>
            <td class="text-center">
            <a name="" id="" class="" href="<?php echo e(route('category.edit', $cat->id)); ?>" role="button">
                <i class="fas fa-edit"></i>
            </a>
                <a name="" id=""  href="<?php echo e(route('category.destroy', $cat->id)); ?>" role="button" class="btndelete">
                    <i class="fas fa-trash"></i>
                </a>
            
                <a name="" id="" class="" href="#" role="button">
                    <i class="fas fa-file"></i>
                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="card-footer clearfix">
        <?php echo e($data->appends(request()->all())->links()); ?>

    </div>
    
    </div>
</div>
<form action="" method="post" id="form-delete">
    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $('.btndelete').click(function(event){
        event.preventDefault();
        var _href = $(this).attr('href')
    $('form#form-delete').attr('action', _href) 
    if(confirm('Ban co muon xoa khong?')){
        $("form#form-delete").submit();   
    }   
     
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\lrv8\resources\views/backend/category/index.blade.php ENDPATH**/ ?>