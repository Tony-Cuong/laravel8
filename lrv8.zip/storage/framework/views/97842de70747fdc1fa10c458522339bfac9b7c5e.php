<div class="alert alert-success" role="alert">
  <h4 class="alert-heading"></h4>
  <p><?php echo e($title); ?></p>
  <hr>
  <p class="mb-0"><?php echo e($message); ?></p>
  <p class="container">
    Name <?php echo e($getOwner('Cuong')); ?>

  </p>
  <p class="card-text">Weight: <?php echo e($getWeight); ?></p>
</div><?php /**PATH F:\Projects\lrv8\resources\views/components/alert.blade.php ENDPATH**/ ?>