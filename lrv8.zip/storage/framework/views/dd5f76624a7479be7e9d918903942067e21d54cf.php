<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ecommer | Template</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?php echo e(url('public/site'), false); ?>/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('public/site'), false); ?>/css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('public/site'), false); ?>/css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('public/site'), false); ?>/css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('public/site'), false); ?>/css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('public/site'), false); ?>/css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('public/site'), false); ?>/css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('public/site'), false); ?>/css/style.css" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Humberger Begin -->
    <?php echo $__env->make('fontend.blocks.humberger', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Humberger End -->

    <!-- Header Section Begin -->
    <?php echo $__env->make('fontend.blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Header Section End -->

    <?php echo $__env->yieldContent('main'); ?>

    <!-- Footer Section Begin -->
    <?php echo $__env->make('fontend.blocks.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
<script src="<?php echo e(url('public/site'), false); ?>/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo e(url('public/site'), false); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo e(url('public/site'), false); ?>/js/jquery.nice-select.min.js"></script>
<script src="<?php echo e(url('public/site'), false); ?>/js/jquery-ui.min.js"></script>
<script src="<?php echo e(url('public/site'), false); ?>/js/jquery.slicknav.js"></script>
<script src="<?php echo e(url('public/site'), false); ?>/js/mixitup.min.js"></script>
<script src="<?php echo e(url('public/site'), false); ?>/js/owl.carousel.min.js"></script>
<script src="<?php echo e(url('public/site'), false); ?>/js/main.js"></script>



</body>

</html><?php /**PATH F:\Projects\lrv8\resources\views/layouts/site.blade.php ENDPATH**/ ?>