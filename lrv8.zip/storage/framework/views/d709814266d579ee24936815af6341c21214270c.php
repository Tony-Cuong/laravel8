
<?php $__env->startSection('title','Edit Category'); ?>
<?php $__env->startSection('main'); ?>
<div class="container">
    <form action="<?php echo e(route('category.update', $category->id)); ?>" method="POST" role="from">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <input type="hidden" name="id" value="<?php echo e($category->id); ?>">
    <div class="form-group">
      <label for="">Name</label>
      <input type="text" name="name" value="<?php echo e($category->name); ?>" class="form-control" placeholder="Input Name">
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <small class="help-block"><?php echo e($message); ?></small>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
      <label for="">Status</label>
      <div class="form-group">
          <label class="">
          <input type="radio" class="" name="status" id="status" value="1" checked>
          Public
        </label>
        <label class="">
        <input type="radio" class="" name="status" value="0">
        Private
        </label>
      </div>
      <div class="form-group">
        <label for="">Prioty</label>
        <input type="number" name="prioty" value="<?php echo e($category->prioty); ?>" class="form-control">
        <?php $__errorArgs = ['prioty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small id="helpId" class="help-block"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <a href="<?php echo e(route('category.index')); ?>" class="btn btn-secondary" tabindex="5">Cancel</a>
      <button type="submit" class="btn btn-primary" tabindex="4">Save data</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\lrv8\resources\views/backend/category/edit.blade.php ENDPATH**/ ?>