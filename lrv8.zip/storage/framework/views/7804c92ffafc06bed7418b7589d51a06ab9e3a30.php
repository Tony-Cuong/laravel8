
<?php $__env->startSection('title', 'Create product'); ?>
<?php $__env->startSection('main'); ?>
    <div class="container">
        <form action="<?php echo e(route('product.store'), false); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-9">
                    <div class="form-group">
                        <label for="">Name</label>
                        <input type="text" name="name" id="" class="form-control" placeholder="Input Name">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="help-block"><?php echo e($message, false); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="">Description</label>
                        <textarea name="description" id="description" cols="30" rows="10"></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="help-block"><?php echo e($message, false); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="">Image List</label>
                        <div class="input-group">
                            <input type="text" name="image_list" id="image_list" class="form-control">
                            <span class="input-group-btn">
                                <!-- Button trigger modal -->
                                <button class="btn btn-secondary" type="button" data-toggle="modal" data-target="#imgList">
                                    <i class="fa fa-image" aria-hidden="true"></i>
                                </button>
                            </span>
                        </div>
                    </div>
                    <div class="row" id="show_img_list">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="">Category</label>
                        <select name="category_id" id="" class="form-control">
                            <option value="-">Select one</option>
                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id, false); ?>"><?php echo e($cat->name, false); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Price</label>
                        <input type="text" name="price" id="" class="form-control" placeholder="Input price">
                    </div>
                    <div class="form-group">
                        <label for="">Sale Price</label>
                        <input type="text" name="sale_price" id="" class="form-control" placeholder="Input sale price">
                    </div>
                    <label for="">Status</label>
                    <div class="form-group">
                        <label class="">
                            <input type="radio" class="" name="status" id="status" value="1" checked>
                            Public
                        </label>
                        <label class="">
                            <input type="radio" class="" name="status" value="0">
                            Private
                        </label>
                    </div>
                    <div class="form-group">
                        <label for="">Image</label>
                        <!--<input type="file" name="file_upload" id="" class="form-control">-->
                        <div class="input-group">
                            <input type="text" class="form-control" name="img" id="img" aria-label="">
                            <span class="input-group-btn">
                                <!-- Button trigger modal -->
                                <button class="btn btn-secondary" type="button" data-toggle="modal" data-target="#modelId">
                                    <i class="fa fa-image" aria-hidden="true"></i>
                                </button>
                            </span>
                        </div>
                        <img src="" id="img" style="">
                    </div>
                </div>
            </div>

            <a href="<?php echo e(route('product.index'), false); ?>" class="btn btn-secondary" tabindex="5">Cancel</a>
            <button type="submit" class="btn btn-primary" tabindex="4">Save data</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<!-- Modal -->
<div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-custom" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Media</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <iframe src="<?php echo e(url('public/file/dialog.php?field_id=img'), false); ?>" frameborder="0"
                    style="width:100%; hieght:500px; "></iframe>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save</button>
            </div>
        </div>
    </div>
</div>
<!--model media list-->
<div class="modal fade" id="imgList" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-custom" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Media</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <iframe src="<?php echo e(url('public/file/dialog.php?field_id=image_list'), false); ?>" frameborder="0"
                    style="width:100%; hieght:500px; "></iframe>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(url('public/backend'), false); ?>/plugins/summernote/summernote-bs4.min.js"></script>
    <script>
        $('#description').summernote({
            height: 210,
            placeholder: "Product description"
        })

        $('#modelId').on('hide.bs.modal', event => {
            var _name_img = $('input#img').val();
            var _link = "<?php echo e(url('public/upload'), false); ?>/" + _name_img;
            $('img#img').attr('src', _link);
            $('img#img').attr('style', 'width:60px;');
        });

        $('#imgList').on('hide.bs.modal', event => {
            var _name_img = $('input#image_list').val();
            var _html = '';
            if (/^[\],:{}\s]*$/.test(_name_img.replace(/\\["\\\/bfnrtu]/g, '@').replace(
                    /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').replace(
                    /(?:^|:|,)(?:\s*\[)+/g, ''))) {
                var _array_img = $.parseJSON(_name_img);
                for (let i = 0; i < _array_img.length; i++) {
                    let _link_img = "<?php echo e(url('public/upload'), false); ?>/" + _array_img[i];
                    _html += '<div class="col-md-4">';
                    _html += '<img src="' + _link_img + '" alt="" style="width: 100%;">';
                    _html += '</div>';
                }
            } else {
                let _link_img = "<?php echo e(url('public/upload'), false); ?>/" + _name_img;
                _html += '<div class="col-md-4">';
                _html += '<img src="' + _link_img + '" alt="" style="width: 100%;">';
                _html += '</div>';
            }

            $('#show_img_list').html(_html);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(url('public/backend'), false); ?>/plugins/summernote/summernote-bs4.min.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\lrv8\resources\views/backend/product/create.blade.php ENDPATH**/ ?>