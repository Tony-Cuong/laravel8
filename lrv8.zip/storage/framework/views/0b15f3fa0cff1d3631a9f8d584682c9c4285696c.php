
<?php $__env->startSection('main'); ?>
    <ul class="list-group">
        <li class="list-group-item d-flex justify-content-between align-items-center active">
            Active list item
            <span class="badge badge-secondary badge-pill">pill1</span>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            List item
            <span class="badge badge-secondary badge-pill">pill2</span>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-center disabled">
            Disabled item
            <span class="badge badge-secondary badge-pill">pill3</span>
        </li>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\lrv8\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>